

<?php $__env->startSection('title', 'Edit Dealer'); ?>

<?php $__env->startSection('contents'); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-4">
                <div class="p-6 text-gray-900">
                    <h3 class="mb-0">Update Dealer</h3>
                    <hr />

                    
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul class="list-unstyled">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        
                                        <?php echo e($error); ?>

                                        
                                        
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    

                    <form action="<?php echo e(route('dealer/update', $dealer->_id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="row">
                            <div class="col mb-3">
                                <label class="form-label">Name</label>
                                <input type="text" name="name" class="form-control" placeholder="Name"
                                    value="<?php echo e(old('name', $dealer->name)); ?>">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" class="form-control" placeholder="Email"
                                    value="<?php echo e(old('email', $dealer->email)); ?>">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col mb-3">
                                <label class="form-label">User City</label>
                                <input type="text" name="user_city" class="form-control" placeholder="User City"
                                    value="<?php echo e(old('user_city', $dealer->user_city)); ?>">
                                <?php $__errorArgs = ['user_city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col mb-3">
                                <label class="form-label">Mobile</label>
                                <input type="text" name="mobile" class="form-control" placeholder="Mobile"
                                    value="<?php echo e(old('mobile', $dealer->mobile)); ?>">
                                <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php $__currentLoopData = $errors->get('mobile'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="text-danger"><?php echo e($error); ?></span><br>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row">
                            <input type="hidden" name="otp_status" class="form-control"
                                value="<?php echo e(old('otp_status', $dealer->otp_status)); ?>">
                        </div>
                        <div class="row">
                            <div class="col mb-3">
                                <label class="form-label">Role</label>
                                <select name="role" class="form-control">
                                    <option value="user" <?php echo e(old('role', $dealer->role) == 'user' ? 'selected' : ''); ?>>
                                        User</option>
                                    <option value="admin" <?php echo e(old('role', $dealer->role) == 'admin' ? 'selected' : ''); ?>>
                                        Admin</option>
                                </select>
                                <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col mb-3">
                                <label class="form-label">Status</label>
                                <select name="status" class="form-control">
                                    <option value="1" <?php echo e(old('status', $dealer->status) ? 'selected' : ''); ?>>Active
                                    </option>
                                    <option value="0" <?php echo e(!old('status', $dealer->status) ? 'selected' : ''); ?>>InActive
                                    </option>
                                </select>
                                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col mb-3">
                                <label class="form-label">Profile</label>
                                <?php if(isset($dealer->image)): ?>
                                    <img src="<?php echo e(asset($dealer->image)); ?>" alt="Profile Image" class="img-thumbnail" style="max-width: 200px;">
                                    <div class="mt-2">
                                        <label for="image" class="file-upload-btn btn btn-primary">
                                            Update picture
                                            <input type="file" id="image" name="image" class="form-control inputfile" accept="image/*">
                                        </label>
                                        <small class="text-muted">Upload a new image to update</small>
                                    </div>
                                <?php else: ?>
                                    <label for="image" class="file-upload-btn btn btn-primary">
                                        Upload Image
                                        <input type="file" id="image" name="image" class="form-control inputfile" accept="image/*">
                                    </label>
                                    <small class="text-muted">Upload a profile image</small>
                                <?php endif; ?>
                            </div>
                            <div class="col mb-3">
                                <label class="form-label">User Pincode</label>
                                <input type="text" name="user_pincode" class="form-control" placeholder="User Pincode" value="<?php echo e(old('user_pincode', $dealer->user_pincode)); ?>">
                                <?php $__errorArgs = ['user_pincode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col mb-3">
                                <label class="form-label">RERA Number</label>
                                <input type="text" name="rera_number" class="form-control" placeholder="RERA Number"
                                    value="<?php echo e(old('rera_number', $dealer->rera_number)); ?>">
                                <?php $__errorArgs = ['rera_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row justify-content-between">
                            <div class="col d-flex justify-content-end">
                                <div class="d-grid">
                                    <button class="btn btn-warning btn-inline">Update</button>
                                </div>
                            </div>
                            <div class="col-auto">
                                <div class="d-grid">
                                    <a href="<?php echo e(route('dealers')); ?>" class="btn btn-danger btn-block">Cancel</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Unify-laravel-mongodb\resources\views/dealer/edit.blade.php ENDPATH**/ ?>
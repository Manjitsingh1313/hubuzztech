

<?php $__env->startSection('title', 'Hubuzztechnology(Unify)'); ?>

<?php $__env->startSection('contents'); ?>
    

    

    <?php if($message): ?>
        <div class="alert alert-success" id="successAlert">
            <?php echo e($message); ?>

        </div>
        <script>
            setTimeout(function() {
                document.getElementById('successAlert').remove();
            }, 3000); // 3000 milliseconds = 3 seconds
        </script>
    <?php endif; ?>


    <div class="row">

        <!-- Users Card -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Total Users</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($users->count()); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-users fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Properties Card -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Total Properties</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($properties->count()); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-home fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Active Users Card -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                Active</div>
                            <div class="row no-gutters align-items-center">
                                <div class="col-auto">
                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?php echo e($activeUsersCount); ?></div>
                                </div>
                                <div class="col">
                                    <div class="progress progress-sm mr-2">
                                        
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-auto">
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Inactive Users Card -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Inactive</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($inactiveUsersCount); ?></div>
                        </div>
                        <div class="col-auto">
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>




        <!-- Buttons -->
        <div class="col-12 mb-4">
            <button class="btn btn-primary" onclick="window.location.href='<?php echo e(route('dealers')); ?>'">Show Dealers</button>
            <button class="btn btn-secondary" onclick="window.location.href='<?php echo e(route('properties')); ?>'">Show
                Properties</button>
        </div>

        <img src="<?php echo e(asset('/assets/images/column-chart.webp')); ?>" alt="Inactive Icon"   style="width: 100%; height: 70vh;"/>
    </div>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Unify-laravel-mongodb\resources\views/dashboard.blade.php ENDPATH**/ ?>





<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

  <!-- Sidebar - Brand -->
  <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('dashboard')); ?>">
      <div class="sidebar-brand-icon ">
        <img src="<?php echo e(asset('assets/images/logo-withoutbg2.png')); ?>" alt="Profile Image" style="max-width: 50px; margin-bottom: 15px;">
      </div>
      <div class="sidebar-brand-text mx-3">Hubuzz technology</div>
  </a>

  <!-- Divider -->
  <hr class="sidebar-divider my-0">

  <!-- Nav Item - Dashboard -->
  <li class="nav-item ">
      <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
  </li>

  <!-- Divider -->
  

  <!-- Heading -->
  
  <li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('dealers')); ?>">
        <i class="fas fa-fw fa-user"></i>
        <span>Dealers</span></a>
</li>
  <!-- Nav Item - Pages Collapse Menu -->
  

  <!-- Nav Item - Utilities Collapse Menu -->
  

  <!-- Divider -->
  

  <!-- Heading -->
  

  <!-- Nav Item - Pages Collapse Menu -->
  

  <!-- Nav Item - Charts -->
  <li class="nav-item">
      <a class="nav-link" href="<?php echo e(route('properties')); ?>">
        <i class="fas fa-fw fa-building"></i>
          <span>Properties</span></a>
  </li>

  <!-- Nav Item - Tables -->
  

  <!-- Divider -->
  <hr class="sidebar-divider d-none d-md-block">

  <!-- Sidebar Toggler (Sidebar) -->
  <div class="text-center d-none d-md-inline" style="position: absolute; bottom: 0;">
      <button class="rounded-circle border-0" id="sidebarToggle"></button>
  </div>

  <!-- Sidebar Message -->
  

</ul><?php /**PATH E:\Unify-laravel-mongodb\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>
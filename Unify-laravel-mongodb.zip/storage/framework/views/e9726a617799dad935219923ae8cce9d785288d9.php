<footer class="sticky-footer bg-white">
  <div class="container my-auto">
    <div class="copyright text-center my-auto">
      <span>Hubuzz-techonlogy</span>
    </div>
  </div>
</footer><?php /**PATH E:\Unify-laravel-mongodb\resources\views/layouts/footer.blade.php ENDPATH**/ ?>
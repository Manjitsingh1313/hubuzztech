@extends('layouts.app')

@section('title', 'Profile')

@section('contents')
    <h1 class="mb-0">Profile</h1>
    <hr />

    @if(isset($user))
        <p>Welcome, {{ $user['name'] }}</p>
        <p>Email: {{ $user['email'] }}</p>
        <p>Mobile: {{ $user['mobile'] }}</p>
        <!-- Display other user information as needed -->

        <form method="POST" enctype="multipart/form-data" id="profile_setup_frm" action="">
            @csrf <!-- Add CSRF token for form submission -->
            <div class="row">
                <div class="col-md-12 border-right">
                    <div class="p-3 py-5">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h4 class="text-right">Profile Settings</h4>
                        </div>
                        <div class="row" id="res"></div>
                        <div class="row mt-2">
                            <div class="col-md-6">
                                <label class="labels">Name</label>
                                <input type="text" name="name" class="form-control" placeholder="First name" value="{{ $user['name'] }}">
                            </div>
                            <div class="col-md-6">
                                <label class="labels">Email</label>
                                <input type="text" name="email" class="form-control" value="{{ $user['email'] }}" placeholder="Email" {{ isset($user['email']) ? 'disabled' : '' }}>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-6">
                                <label class="labels">Phone</label>
                                <input type="text" name="mobile" class="form-control" placeholder="Phone Number" value="{{ $user['mobile'] }}" {{ isset($user['mobile']) ? 'disabled' : '' }}>
                            </div>
                            <div class="col-md-6">
                                <label class="labels">Address</label>
                                <input type="text" name="address" class="form-control" value="{{ $user['address'] }}" placeholder="Address">
                            </div>
                        </div>
                        {{-- <div class="mt-5 text-center">
                            <button id="btn" class="btn btn-primary profile-button" type="submit">Save Profile</button>
                        </div> --}}
                    </div>
                </div>
            </div>   
        </form>
    @else
        <p>You are not logged in. Please <a href="{{ route('login') }}">login</a> to view your profile.</p>
    @endif
@endsection
